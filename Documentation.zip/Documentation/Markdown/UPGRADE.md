# Upgrade

Mobile ActionLog v4.1.0 is an initial release.
There is no upgrade path available from previous releases.

* Deleting the tables from the database is required, since there are incompatible changes.

* The content of the `application.yaml` file was not changed to previous releases in the v4 series.

