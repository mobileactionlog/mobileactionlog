# Mobile ActionLog

Mobile ActionLog Android App and SyncServer Release v4

## [Release Notes](./RELEASE-NOTES.html)
## [Installation Instructions](./INSTALL.html)
## [Administrator Guide](./ADMIN_GUIDE.html)
## [User Guide](./USER_GUIDE.html)
## [Upgrade Manual](./UPGRADE.html)

## Note:

The sources to this documentation are written in `markdown`.
`pandoc` is used to create the HTML version of the documentation.